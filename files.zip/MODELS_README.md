# 📊 Modèles de Données - Guide d'Installation

## Fichiers créés :

1. **vocabulary_list.dart** - Liste de vocabulaire
2. **concept.dart** - Concept/sens
3. **word_variant.dart** - Variante de mot
4. **variant_progress.dart** - Progression par variante

---

## 📁 Où les placer ?

Copiez ces 4 fichiers dans :

```
vocabulary_app/
└── lib/
    └── models/
        ├── vocabulary_list.dart
        ├── concept.dart
        ├── word_variant.dart
        └── variant_progress.dart
```

---

## ✅ Vérification rapide

Après avoir copié les fichiers, testez :

```bash
cd vocabulary_app
flutter analyze lib/models/
```

Vous ne devriez avoir aucune erreur ! ✅

---

## 🎯 Utilisation des modèles

### Créer une liste de vocabulaire

```dart
import 'package:uuid/uuid.dart';

final list = VocabularyList(
  id: Uuid().v4(),
  name: "Salutations quotidiennes",
  lang1Code: "fr",
  lang2Code: "ko",
  createdAt: DateTime.now().toIso8601String(),
  totalConcepts: 0,
);

// Conversion pour SQLite
final map = list.toMap();
print(map);

// Depuis SQLite
final listFromDb = VocabularyList.fromMap(map);
```

### Créer un concept

```dart
final concept = Concept(
  id: Uuid().v4(),
  listId: list.id,
  category: "greetings",
  contextLang1: "salutation formelle",
  contextLang2: "격식있는 인사",
  createdAt: DateTime.now().toIso8601String(),
);
```

### Créer une variante

```dart
final variant = WordVariant(
  id: Uuid().v4(),
  conceptId: concept.id,
  word: "안녕하세요",
  langCode: "ko",
  registerTag: "formal",
  contextTags: ["oral", "written"],
  isPrimary: true,
  createdAt: DateTime.now().toIso8601String(),
);
```

### Créer une progression

```dart
final progress = VariantProgress(
  id: Uuid().v4(),
  variantId: variant.id,
  direction: "fr_to_ko",
  timesShownAsAnswer: 10,
  timesAnsweredCorrectly: 7,
);

print(progress.masteryLevel); // 0.7
print(progress.isKnown);      // true (>= 0.7)
```

### Mettre à jour la progression

```dart
// Après une bonne réponse
final updated = progress.copyWith(
  timesShownAsAnswer: progress.timesShownAsAnswer + 1,
  timesAnsweredCorrectly: progress.timesAnsweredCorrectly + 1,
  lastSeenDate: DateTime.now().toIso8601String(),
);

// masteryLevel et isKnown sont recalculés automatiquement !
print(updated.masteryLevel); // 0.727...
```

---

## 🔑 Points importants

### VocabularyList
- `isDownloaded` → bool mais stocké comme int (0/1) en SQLite
- `downloadStatus` → 'idle', 'downloading', 'completed', 'error'

### Concept
- Tous les champs sauf `id`, `listId`, `createdAt` sont optionnels
- Utilisez `category` pour grouper (greetings, food, transport...)

### WordVariant
- `contextTags` → Liste stockée en JSON dans SQLite
- `registerTag` → 'formal', 'informal', 'neutral', 'very_informal'
- `isPrimary` → true pour la variante principale du concept

### VariantProgress
- `masteryLevel` calculé automatiquement : correct / shown
- `isKnown` calculé automatiquement : masteryLevel >= 0.7
- Utilisez `copyWith()` pour mettre à jour, les calculs sont automatiques

---

## 🚀 Prochaines étapes

Maintenant que les modèles sont créés, vous pouvez :

1. **Créer la base de données SQLite** (tables et schéma)
2. **Créer les repositories** (accès aux données)
3. **Créer les services** (logique métier)
4. **Créer l'interface** (écrans et widgets)

---

## ❓ Questions ?

Les modèles sont prêts à l'emploi ! Si vous avez des erreurs, vérifiez que :
- Les fichiers sont bien dans `lib/models/`
- Vous avez le package `uuid` dans votre `pubspec.yaml` (déjà inclus)
- Vous avez fait `flutter pub get`
